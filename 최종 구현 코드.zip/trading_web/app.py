from flask import Flask, render_template, request, jsonify, redirect, url_for
import sys
import os
import threading
import time
import logging
from queue import Queue
import datetime

# 3st 폴더의 경로를 시스템 경로에 추가
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '3st'))

# 3st 폴더의 .env 파일 경로 설정
from dotenv import load_dotenv
env_path = os.path.join(os.path.dirname(__file__), '..', '3st', '.env')
load_dotenv(env_path)

from strategy import Strategy
from config import TRADING_COIN, STOP_LOSS_PERCENT, TRADING_AMOUNT, UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY
from utils import get_current_price, get_rsi
from notifier import notify_trade, notify_error
from trade import execute_buy, execute_sell

app = Flask(__name__)

# Flask 기본 로깅 비활성화
app.logger.disabled = True
log = logging.getLogger('werkzeug')
log.disabled = True

# 로그 메시지를 저장할 큐
log_queue = Queue(maxsize=100)
is_trading = False
active_strategy = None
trading_thread = None

class WebHandler(logging.Handler):
    def emit(self, record):
        # 트레이딩 관련 로그만 저장
        if "현재가" in record.getMessage() or "매수" in record.getMessage() or "매도" in record.getMessage() or "RSI" in record.getMessage():
            log_entry = {
                'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'level': record.levelname,
                'message': record.getMessage()
            }
            if log_queue.full():
                log_queue.get()
            log_queue.put(log_entry)

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()
logger.handlers = []  # 기존 핸들러 제거
logger.addHandler(WebHandler())

def trading_loop(strategy_type):
    global is_trading
    strategy = Strategy(strategy_type)
    
    logging.info(f"\n트레이딩을 시작합니다...")
    logging.info(f"거래 코인: {TRADING_COIN}")
    logging.info(f"거래 금액: {TRADING_AMOUNT:,.0f}원")
    logging.info(f"손절 비율: {STOP_LOSS_PERCENT}%")
    
    notify_trade("시작", get_current_price(TRADING_COIN), TRADING_AMOUNT, strategy_type)
    
    while is_trading:
        try:
            current_price = get_current_price(TRADING_COIN)
            rsi = get_rsi(TRADING_COIN)
            
            logging.info(f"현재가: {current_price:,.0f}원, RSI: {rsi:.2f}")
            
            if strategy.should_buy(current_price):
                logging.info("매수 신호 발생!")
                notify_trade("매수", current_price, TRADING_AMOUNT, strategy_type)
                # 실제 매수 실행
                buy_result = execute_buy()
                if buy_result:
                    logging.info("매수 성공!")
                else:
                    logging.error("매수 실패!")
                
            if strategy.should_sell(current_price):
                logging.info("매도 신호 발생!")
                notify_trade("매도", current_price, TRADING_AMOUNT, strategy_type)
                # 실제 매도 실행
                sell_result = execute_sell()
                if sell_result:
                    logging.info("매도 성공!")
                else:
                    logging.error("매도 실패!")
                
            time.sleep(60)  # 1분 간격 유지
            
        except Exception as e:
            error_msg = f"트레이딩 중 에러 발생: {e}"
            logging.error(error_msg)
            notify_error(error_msg)
            time.sleep(60)  # 에러 발생시에도 1분 대기

@app.route('/')
def index():
    strategies = [
        {
            'id': 'rsi',
            'name': 'RSI 전략',
            'description': 'RSI 지표를 이용한 매매 전략'
        },
        {
            'id': 'rsi_macd',
            'name': 'RSI + MACD 전략',
            'description': 'RSI와 MACD를 결합한 매매 전략'
        },
        {
            'id': 'bollinger',
            'name': '볼린저 밴드 전략',
            'description': '볼린저 밴드를 이용한 매매 전략'
        },
        {
            'id': 'squeeze_momentum',
            'name': '스퀴즈 모멘텀 전략',
            'description': '볼린저 밴드와 켈트너 채널을 이용한 모멘텀 전략'
        },
        {
            'id': 'dema_rsi',
            'name': 'DEMA + RSI 전략',
            'description': 'DEMA와 RSI를 결합한 개선된 매매 전략'
        }
    ]
    return render_template('index.html', 
                         strategies=strategies, 
                         is_trading=is_trading,
                         active_strategy=active_strategy)

@app.route('/start_trading/<strategy_type>')
def start_trading(strategy_type):
    global active_strategy, trading_thread, is_trading
    
    if is_trading:
        stop_trading()
    
    is_trading = True
    active_strategy = strategy_type
    trading_thread = threading.Thread(target=trading_loop, args=(strategy_type,))
    trading_thread.start()
    
    return redirect(url_for('trading', strategy_type=strategy_type))

@app.route('/stop_trading')
def stop_trading():
    global is_trading, active_strategy, trading_thread
    
    if is_trading:
        is_trading = False
        if trading_thread:
            trading_thread.join()
        active_strategy = None
    
    return redirect(url_for('index'))

@app.route('/trading/<strategy_type>')
def trading(strategy_type):
    return render_template('trading.html', 
                         strategy_type=strategy_type,
                         trading_coin=TRADING_COIN,
                         trading_amount=TRADING_AMOUNT,
                         stop_loss=STOP_LOSS_PERCENT,
                         is_trading=is_trading)

@app.route('/api/logs')
def get_logs():
    logs = list(log_queue.queue)
    return jsonify(logs)

@app.route('/api/price')
def get_price():
    current_price = get_current_price(TRADING_COIN)
    rsi = get_rsi(TRADING_COIN)
    
    response = {
        'price': current_price,
        'rsi': rsi,
        'is_trading': is_trading
    }
    
    # DEMA+RSI 전략일 경우 추가 정보 제공
    if active_strategy == 'dema_rsi':
        from utils import get_dema
        from config import DEMA_FAST_PERIOD, DEMA_SLOW_PERIOD, DEMA_SIGNAL_PERIOD
        
        dema_fast = get_dema(TRADING_COIN, DEMA_FAST_PERIOD)
        dema_slow = get_dema(TRADING_COIN, DEMA_SLOW_PERIOD)
        dema_signal = get_dema(TRADING_COIN, DEMA_SIGNAL_PERIOD)
        
        macd_dema = dema_fast['dema'] - dema_slow['dema']
        
        response.update({
            'dema_fast': dema_fast['dema'],
            'dema_slow': dema_slow['dema'],
            'dema_signal': dema_signal['dema'],
            'macd_dema': macd_dema
        })
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False) 