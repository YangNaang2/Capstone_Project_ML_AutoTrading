from config import upbit, bot, TELEGRAM_CHAT_ID, TRADING_COIN, TRADING_AMOUNT
import json
import pyupbit
from utils import get_current_price, get_balance

def sell(ticker):
    # time.sleep(0.1)
    balance = upbit.get_balance(ticker)
    s = upbit.sell_market_order(ticker, balance)
    msg = str(ticker)+"매도 시도"+"\n"+json.dumps(s, ensure_ascii = False)
    print(msg)
    bot.sendMessage(TELEGRAM_CHAT_ID,msg)
    
def buy(ticker, money):
    # time.sleep(0.1)
    b = upbit.buy_market_order(ticker, money)
    try:
        if b['error']:
            b = upbit.buy_market_order(ticker, 100000)
            msg = "돈 좀 부족해서 " + str(ticker)+" "+str(100000)+"원 매수시도"+"\n"+json.dumps(b, ensure_ascii = False)
    except:
        msg = str(ticker)+" "+str(money)+"원 매수시도"+"\n"+json.dumps(b, ensure_ascii = False)
    print(msg)
    bot.sendMessage(TELEGRAM_CHAT_ID,msg)

def execute_buy():
    """매수 실행"""
    try:
        current_price = get_current_price(TRADING_COIN)
        if current_price is None:
            return False
            
        # 주문 가능 금액 확인
        balance = get_balance("KRW")
        if balance < TRADING_AMOUNT:
            print(f"주문 가능 금액 부족: {balance:,}원")
            return False
            
        # 매수 주문 실행
        result = upbit.buy_market_order(TRADING_COIN, TRADING_AMOUNT)
        if result:
            print(f"매수 주문 성공: {TRADING_COIN}, {TRADING_AMOUNT:,}원")
            return True
        else:
            print("매수 주문 실패")
            return False
            
    except Exception as e:
        print(f"매수 실행 중 오류 발생: {e}")
        return False

def execute_sell():
    """매도 실행"""
    try:
        # 보유 수량 확인
        balance = get_balance(TRADING_COIN)
        if balance <= 0:
            print("매도할 수량이 없습니다.")
            return False
            
        # 현재가 확인
        current_price = get_current_price(TRADING_COIN)
        if current_price is None:
            return False
            
        # 전체 보유 수량 매도
        result = upbit.sell_market_order(TRADING_COIN, balance)
        if result:
            print(f"매도 주문 성공: {TRADING_COIN}, {balance} 개")
            return True
        else:
            print("매도 주문 실패")
            return False
            
    except Exception as e:
        print(f"매도 실행 중 오류 발생: {e}")
        return False