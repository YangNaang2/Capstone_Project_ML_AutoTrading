import pyupbit
from utils import get_current_price, get_rsi, get_macd, get_bollinger_bands, get_squeeze_momentum, get_dema
from config import TRADING_COIN, upbit, RSI_OVERSOLD, RSI_OVERBOUGHT, DEMA_FAST_PERIOD, DEMA_SLOW_PERIOD, DEMA_SIGNAL_PERIOD
from logger import logger
from trade import execute_sell
import logging

class Strategy:
    def __init__(self, strategy_type="rsi", stop_loss_percent=2.0):
        self.strategy_type = strategy_type
        self.stop_loss_percent = stop_loss_percent
        self.last_buy_price = None

    def check_stop_loss(self, current_price):
        """손절 조건 확인"""
        if self.last_buy_price is None:
            return False
        
        loss_percent = ((self.last_buy_price - current_price) / self.last_buy_price) * 100
        return loss_percent >= self.stop_loss_percent

    def should_buy(self, current_price):
        """매수 신호 확인"""
        try:
            if self.strategy_type == "rsi":
                rsi = get_rsi(TRADING_COIN)
                logging.info(f"RSI: {rsi:.2f}")
                return rsi <= RSI_OVERSOLD
                
            elif self.strategy_type == "rsi_macd":
                rsi = get_rsi(TRADING_COIN)
                macd = get_macd(TRADING_COIN)
                logging.info(f"RSI: {rsi:.2f}, MACD: {macd['macd']:.2f}, Signal: {macd['signal']:.2f}")
                return rsi <= RSI_OVERSOLD and macd['macd'] > macd['signal']
                
            elif self.strategy_type == "bollinger":
                bb = get_bollinger_bands(TRADING_COIN)
                logging.info(f"현재가: {current_price:,.0f}, 하단밴드: {bb['lower']:,.0f}")
                return current_price <= bb['lower']
                
            elif self.strategy_type == "squeeze_momentum":
                squeeze = get_squeeze_momentum(TRADING_COIN)
                logging.info(f"모멘텀 히스토그램: {squeeze['mom_hist']:.2f}, 이전: {squeeze['prev_mom_hist']:.2f}")
                return squeeze['prev_mom_hist'] < 0 and squeeze['mom_hist'] > 0
                
            elif self.strategy_type == "dema_rsi":
                rsi = get_rsi(TRADING_COIN)
                dema_fast = get_dema(TRADING_COIN, DEMA_FAST_PERIOD)
                dema_slow = get_dema(TRADING_COIN, DEMA_SLOW_PERIOD)
                dema_signal = get_dema(TRADING_COIN, DEMA_SIGNAL_PERIOD)
                
                macd_dema = dema_fast['dema'] - dema_slow['dema']
                prev_macd_dema = dema_fast['prev_dema'] - dema_slow['prev_dema']
                
                logging.info(f"RSI: {rsi:.2f}, MACD_DEMA: {macd_dema:.2f}, Signal_DEMA: {dema_signal['dema']:.2f}")
                
                return (macd_dema > dema_signal['dema'] and 
                        macd_dema > 0 and 
                        macd_dema > prev_macd_dema and 
                        rsi > 50)
                
            return False
            
        except Exception as e:
            logging.error(f"매수 신호 확인 중 에러: {e}")
            return False

    def should_sell(self, current_price):
        """매도 신호 확인"""
        try:
            # 손절 조건 확인
            if self.check_stop_loss(current_price):
                logging.info("손절 조건 만족")
                execute_sell()
                return True
            
            if self.strategy_type == "rsi":
                rsi = get_rsi(TRADING_COIN)
                logging.info(f"RSI: {rsi:.2f}")
                return rsi >= RSI_OVERBOUGHT
                
            elif self.strategy_type == "rsi_macd":
                rsi = get_rsi(TRADING_COIN)
                macd = get_macd(TRADING_COIN)
                logging.info(f"RSI: {rsi:.2f}, MACD: {macd['macd']:.2f}, Signal: {macd['signal']:.2f}")
                return rsi >= RSI_OVERBOUGHT and macd['macd'] < macd['signal']
                
            elif self.strategy_type == "bollinger":
                bb = get_bollinger_bands(TRADING_COIN)
                logging.info(f"현재가: {current_price:,.0f}, 상단밴드: {bb['upper']:,.0f}")
                return current_price >= bb['upper']
                
            elif self.strategy_type == "squeeze_momentum":
                squeeze = get_squeeze_momentum(TRADING_COIN)
                logging.info(f"모멘텀 히스토그램: {squeeze['mom_hist']:.2f}, 이전: {squeeze['prev_mom_hist']:.2f}")
                return squeeze['prev_mom_hist'] > 0 and squeeze['mom_hist'] < 0
                
            elif self.strategy_type == "dema_rsi":
                rsi = get_rsi(TRADING_COIN)
                dema_fast = get_dema(TRADING_COIN, DEMA_FAST_PERIOD)
                dema_slow = get_dema(TRADING_COIN, DEMA_SLOW_PERIOD)
                dema_signal = get_dema(TRADING_COIN, DEMA_SIGNAL_PERIOD)
                
                macd_dema = dema_fast['dema'] - dema_slow['dema']
                
                logging.info(f"RSI: {rsi:.2f}, MACD_DEMA: {macd_dema:.2f}, Signal_DEMA: {dema_signal['dema']:.2f}")
                
                return ((macd_dema < dema_signal['dema'] or macd_dema < 0) and rsi < 50)
                
            return False
            
        except Exception as e:
            logging.error(f"매도 신호 확인 중 에러: {e}")
            return False

# 전략 인스턴스 생성
strategy = Strategy("rsi")  # 기본값은 RSI 전략

