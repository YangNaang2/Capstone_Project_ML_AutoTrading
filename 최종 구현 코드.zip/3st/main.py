import time
import pyupbit
import logging
from config import TRADING_COIN, STOP_LOSS_PERCENT, TRADING_AMOUNT
from strategy import Strategy
from utils import get_current_price, get_rsi
from notifier import notify_trade, notify_error
from trade import execute_sell, execute_buy

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def select_strategy():
    """거래 전략 선택"""
    while True:
        print("\n사용할 전략을 선택하세요:")
        print("1. RSI 전략")
        print("2. RSI + MACD 전략")
        print("3. 볼린저 밴드 전략")
        print("4. 스퀴즈 모멘텀 전략")
        print("5. DEMA + RSI 전략")
        
        choice = input("번호를 입력하세요 (1-5): ")
        
        strategy_map = {
            "1": "rsi",
            "2": "rsi_macd",
            "3": "bollinger",
            "4": "squeeze_momentum",
            "5": "dema_rsi"
        }
        
        if choice in strategy_map:
            selected_strategy = strategy_map[choice]
            print(f"\n{selected_strategy.upper()} 전략이 선택되었습니다.")
            return selected_strategy
        else:
            print("\n잘못된 선택입니다. 다시 선택해주세요.")

def main():
    try:
        # 전략 선택
        strategy_type = select_strategy()
        
        # 전략 객체 생성
        strategy = Strategy(strategy_type)
        
        print(f"\n트레이딩을 시작합니다...")
        print(f"거래 코인: {TRADING_COIN}")
        print(f"거래 금액: {TRADING_AMOUNT:,.0f}원")
        print(f"손절 비율: {STOP_LOSS_PERCENT}%")
        
        # 시작 알림
        notify_trade("시작", get_current_price(TRADING_COIN), TRADING_AMOUNT, strategy_type)
        
        while True:
            try:
                current_price = get_current_price(TRADING_COIN)
                rsi = get_rsi(TRADING_COIN)
                
                logging.info(f"현재가: {current_price:,.0f}원, RSI: {rsi:.2f}")
                
                # 매수/매도 신호 확인
                if strategy.should_buy(current_price):
                    logging.info("매수 신호 발생!")
                    notify_trade("매수", current_price, TRADING_AMOUNT, strategy_type)
                    # 여기에 실제 매수 로직 구현
                    buy_result =execute_buy()
                    if buy_result:
                        logging.info(f"매수 성공!")
                    else:
                        logging.error("매수 실패!")
                        
                if strategy.should_sell(current_price):
                    logging.info("매도 신호 발생!")
                    notify_trade("매도", current_price, TRADING_AMOUNT, strategy_type)
                    # 여기에 실제 매도 로직 구현
                    sell_result = execute_sell()
                    if sell_result:
                        logging.info("매도 성공!")
                    else:
                        logging.error("매도 실패!")
                    
                # 1초에서 60초(1분)로 변경
                time.sleep(60)
                
            except Exception as e:
                error_msg = f"트레이딩 중 에러 발생: {e}"
                logging.error(error_msg)
                notify_error(error_msg)
                time.sleep(60)  # 에러 발생시에도 1분 대기
                
    except Exception as e:
        error_msg = f"프로그램 실행 중 에러 발생: {e}"
        logging.error(error_msg)
        notify_error(error_msg)

if __name__ == "__main__":
    main() 