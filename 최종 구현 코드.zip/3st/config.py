import os
from dotenv import load_dotenv
import pyupbit
import telegram

# .env 파일 로드
load_dotenv()

# API 키 설정
UPBIT_ACCESS_KEY = os.getenv('UPBIT_ACCESS_KEY')
UPBIT_SECRET_KEY = os.getenv('UPBIT_SECRET_KEY')
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

# 거래 설정
TRADING_COIN = "KRW-BTC"  # 거래할 코인
TRADING_AMOUNT = 10000  # 거래 금액 (원)
STOP_LOSS_PERCENT = 2.0  # 손절 퍼센트

# RSI 설정
RSI_PERIOD = 14
RSI_OVERSOLD = 30
RSI_OVERBOUGHT = 70

# MACD 설정
MACD_SHORT = 12
MACD_LONG = 26
MACD_SIGNAL = 9

# 볼린저 밴드 설정
BB_PERIOD = 20
BB_STD = 2

# DEMA 설정
DEMA_FAST_PERIOD = 12
DEMA_SLOW_PERIOD = 26
DEMA_SIGNAL_PERIOD = 9

upbit = pyupbit.Upbit(UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY)
bot = telegram.Bot(token=TELEGRAM_BOT_TOKEN)

coin_list = ["KRW-BTC", "KRW-ETH", "KRW-DOGE"]
percent_list = [0.05] * len(coin_list)