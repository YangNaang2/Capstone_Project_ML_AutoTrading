import pyupbit
UPBIT_ACCESS_KEY="LAMvU2XVdpxvJrERCOfdiMqjbkmx4WrZ6EyLTPKl"
UPBIT_SECRET_KEY="obQPKIxOLutmL8XnD4BReanasjM6jdjK4VCERPRG"

upbit = pyupbit.Upbit(UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY)
#1 balance 정상적으로 불러오는지 확인
balance = upbit.get_balance("KRW")
print(balance)  # 원화 잔고 출력
