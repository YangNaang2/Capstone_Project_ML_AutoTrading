from config import bot, mc

def notify(msg):
    bot.send_message(chat_id=mc, text=msg)
    print(msg)