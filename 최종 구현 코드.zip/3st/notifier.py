import requests
import logging
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

def send_telegram_message(message):
    """텔레그램으로 메시지 전송"""
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message
        }
        response = requests.post(url, data=data)
        if response.status_code != 200:
            logging.error(f"텔레그램 메시지 전송 실패: {response.text}")
    except Exception as e:
        logging.error(f"텔레그램 메시지 전송 중 에러: {e}")

def notify_trade(action, current_price, amount, strategy_type=None):
    """거래 알림"""
    strategy_text = f"[{strategy_type}] " if strategy_type else ""
    message = f"🚨 {strategy_text}{action} 신호 발생!\n"
    message += f"현재가: {current_price:,.0f}원\n"
    message += f"거래금액: {amount:,.0f}원"
    send_telegram_message(message)

def notify_error(error_message):
    """에러 알림"""
    message = f"⚠️ 에러 발생!\n{error_message}"
    send_telegram_message(message) 