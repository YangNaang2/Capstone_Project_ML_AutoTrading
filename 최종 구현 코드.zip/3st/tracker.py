import pandas as pd
from datetime import datetime
import os

class TradeTracker:
    def __init__(self):
        self.dataset_file = 'dataset.csv'
        self.saved_data_file = 'saved_data.csv'
        self.initialize_files()
    
    def initialize_files(self):
        """파일 초기화"""
        if not os.path.exists(self.dataset_file):
            df = pd.DataFrame(columns=['timestamp', 'type', 'price', 'amount', 'balance'])
            df.to_csv(self.dataset_file, index=False)
        
        if not os.path.exists(self.saved_data_file):
            df = pd.DataFrame(columns=['date', 'total_trades', 'win_rate', 'profit_loss'])
            df.to_csv(self.saved_data_file, index=False)
    
    def record_trade(self, trade_type, price, amount, balance):
        """거래 기록"""
        try:
            df = pd.read_csv(self.dataset_file)
            new_record = pd.DataFrame({
                'timestamp': [datetime.now()],
                'type': [trade_type],
                'price': [price],
                'amount': [amount],
                'balance': [balance]
            })
            df = pd.concat([df, new_record], ignore_index=True)
            df.to_csv(self.dataset_file, index=False)
        except Exception as e:
            print(f"거래 기록 중 오류 발생: {e}")
    
    def calculate_performance(self):
        """성과 계산"""
        try:
            df = pd.read_csv(self.dataset_file)
            if len(df) == 0:
                return
            
            # 일별 성과 계산
            df['date'] = pd.to_datetime(df['timestamp']).dt.date
            daily_stats = df.groupby('date').agg({
                'type': 'count',
                'price': lambda x: (x[df['type'] == 'sell'] - x[df['type'] == 'buy']).sum()
            }).reset_index()
            
            daily_stats.columns = ['date', 'total_trades', 'profit_loss']
            daily_stats['win_rate'] = daily_stats['profit_loss'].apply(lambda x: 1 if x > 0 else 0)
            
            # 기존 데이터와 병합
            saved_df = pd.read_csv(self.saved_data_file)
            saved_df = pd.concat([saved_df, daily_stats], ignore_index=True)
            saved_df.to_csv(self.saved_data_file, index=False)
            
        except Exception as e:
            print(f"성과 계산 중 오류 발생: {e}")
    
    def get_summary(self):
        """성과 요약"""
        try:
            df = pd.read_csv(self.saved_data_file)
            if len(df) == 0:
                return "거래 기록이 없습니다."
            
            total_trades = df['total_trades'].sum()
            total_profit = df['profit_loss'].sum()
            win_rate = (df['win_rate'].sum() / len(df)) * 100
            
            return f"""
            📊 성과 요약
            총 거래 횟수: {total_trades:,}회
            총 수익률: {total_profit:.2f}%
            승률: {win_rate:.2f}%
            """
        except Exception as e:
            return f"성과 요약 중 오류 발생: {e}"

# 전역 트래커 인스턴스 생성
tracker = TradeTracker() 