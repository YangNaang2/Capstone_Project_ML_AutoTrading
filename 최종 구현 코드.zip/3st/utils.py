import pyupbit
import pandas as pd
import numpy as np
from config import TRADING_COIN, upbit

def get_target_price(ticker, k):
    df = pyupbit.get_ohlcv(ticker, interval="day", count=2)
    yesterday = df.iloc[-2]
    return yesterday['close'] + (yesterday['high'] - yesterday['low']) * k

def get_moving_average(ticker, days):
    df = pyupbit.get_ohlcv(ticker, interval="day", count=days)
    return df['close'].rolling(window=days).mean().iloc[-1]

def get_current_price(ticker):
    """현재가 조회"""
    return pyupbit.get_current_price(ticker)

def get_balance(ticker):
    """잔고 조회"""
    if ticker == "KRW":
        return upbit.get_balance("KRW")
    else:
        return upbit.get_balance(ticker.split("-")[1])

def get_rsi(ticker, period=14):
    """RSI 계산"""
    df = pyupbit.get_ohlcv(ticker, interval="minute1", count=period+1)
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi.iloc[-1]

def get_macd(ticker, short_period=12, long_period=26, signal_period=9):
    """MACD 계산"""
    df = pyupbit.get_ohlcv(ticker, interval="minute1", count=long_period+signal_period)
    
    # 단기, 장기 EMA 계산
    short_ema = df['close'].ewm(span=short_period, adjust=False).mean()
    long_ema = df['close'].ewm(span=long_period, adjust=False).mean()
    
    # MACD, Signal, Histogram 계산
    macd = short_ema - long_ema
    signal = macd.ewm(span=signal_period, adjust=False).mean()
    histogram = macd - signal
    
    return {
        'macd': macd.iloc[-1],
        'signal': signal.iloc[-1],
        'histogram': histogram.iloc[-1]
    }

def get_bollinger_bands(ticker, period=20, std_dev=2):
    """볼린저 밴드 계산"""
    df = pyupbit.get_ohlcv(ticker, interval="minute1", count=period)
    
    # 중간 밴드 (20일 이동평균)
    middle_band = df['close'].rolling(window=period).mean()
    
    # 표준편차
    std = df['close'].rolling(window=period).std()
    
    # 상단, 하단 밴드
    upper_band = middle_band + (std * std_dev)
    lower_band = middle_band - (std * std_dev)
    
    return {
        'upper': upper_band.iloc[-1],
        'middle': middle_band.iloc[-1],
        'lower': lower_band.iloc[-1]
    }

def get_squeeze_momentum(ticker, bb_period=20, bb_dev=2.0, kc_period=20, kc_atr_multiplier=1.5, momentum_period=20):
    """스퀴즈 모멘텀 계산"""
    df = pyupbit.get_ohlcv(ticker, interval="minute1", count=max(bb_period, kc_period, momentum_period * 2))
    
    # 볼린저 밴드 계산
    middle_band = df['close'].rolling(window=bb_period).mean()
    std = df['close'].rolling(window=bb_period).std()
    upper_bb = middle_band + (std * bb_dev)
    lower_bb = middle_band - (std * bb_dev)
    
    # 켈트너 채널 계산
    sma = df['close'].rolling(window=kc_period).mean()
    atr = df['high'].rolling(window=kc_period).max() - df['low'].rolling(window=kc_period).min()
    upper_kc = sma + (atr * kc_atr_multiplier)
    lower_kc = sma - (atr * kc_atr_multiplier)
    
    # 모멘텀 계산
    mom = df['close'] - df['close'].shift(momentum_period)
    mom_sma = mom.rolling(window=momentum_period).mean()
    mom_hist = mom - mom_sma
    
    return {
        'upper_bb': upper_bb.iloc[-1],
        'lower_bb': lower_bb.iloc[-1],
        'upper_kc': upper_kc.iloc[-1],
        'lower_kc': lower_kc.iloc[-1],
        'mom_hist': mom_hist.iloc[-1],
        'prev_mom_hist': mom_hist.iloc[-2] if len(mom_hist) > 1 else 0
    }

def get_dema(ticker, period):
    """DEMA(Double Exponential Moving Average) 계산"""
    df = pyupbit.get_ohlcv(ticker, interval="minute1", count=period*2)
    
    # 첫 번째 EMA 계산
    ema = df['close'].ewm(span=period, adjust=False).mean()
    
    # 두 번째 EMA 계산
    ema2 = ema.ewm(span=period, adjust=False).mean()
    
    # DEMA = 2*EMA1 - EMA2
    dema = 2 * ema - ema2
    
    return {
        'dema': dema.iloc[-1],
        'prev_dema': dema.iloc[-2] if len(dema) > 1 else None
    }
