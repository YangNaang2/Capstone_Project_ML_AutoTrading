from datetime import datetime
import backtrader as bt
import quantstats as qs
import yfinance as yt
import time
import os


def collect_tick(symbol="QQQ", timeframe="1d"):
    if not os.path.exists("./data"):
        os.makedirs("./data")
    time.sleep(1)
    df = yt.download(symbol, "1900-01-01")
    if df.shape[0] == 0:
        print(f"{symbol} ERROR: No Data!!!")
        exit(0)
    file_name = f"./data/{symbol}_{timeframe}_tick.csv"
    print(file_name, "->", df.head(1).index.values[0], "~", df.tail(1).index.values[0])
    print("=" * 10)
    df = df[['Open', 'High', 'Low', 'Adj Close', 'Volume']]
    df.to_csv(file_name, mode='w', header=False, date_format='%Y-%m-%dT%H:%M:%SZ')


class BollingerBandFixedTradeCount(bt.Strategy):
    params = dict(
        log=False,
        max_trades=20,
    )

    def __init__(self):
        self.bband = bt.indicators.BBands(self.datas[0], period=80, devfactor=1)
        self.risk_amount = self.broker.get_value() / self.p.max_trades
        self.highest_balance = self.broker.get_value()

    def next(self):
        current_balance = self.broker.get_value()
        if current_balance > self.highest_balance:
            self.highest_balance = current_balance
            self.risk_amount = self.highest_balance / self.p.max_trades

        top_band = self.bband.top[0]
        mid_band = self.bband.mid[0]
        bot_band = self.bband.bot[0]

        if top_band < self.datas[0].close[0] and self.getposition(self.datas[0]).size == 0:
            order_amount = self.risk_amount / (self.datas[0].close[0] - mid_band)
            self.buy(data=self.datas[0], size=order_amount)

        if mid_band > self.datas[0].close[0] and self.getposition(self.datas[0]).size > 0:
            self.sell(data=self.datas[0], size=self.getposition(self.datas[0]).size)

    def log(self, message):
        if self.p.log:
            print(message)

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        cur_date = order.data.datetime.date(0)
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(
                    f'{cur_date} [매수 주문 실행] 종목: {order.data._name} \t 수량: {order.size} \t 가격: {order.executed.price:.4f}')
            elif order.issell():
                self.log(
                    f'{cur_date} [매도 주문 실행] 종목: {order.data._name} \t 수량: {order.size} \t 가격: {order.executed.price:.4f}')
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log(
                f'{cur_date} {order.status} 주문이 거부되었습니다. 종목: {order.data._name} \t 수량: {order.size} \t 가격: {order.executed.price:.4f}')
            self.log("!Error: Order Rejected")
            exit(1)


# 1일봉 만들기
class SymbolData1d(bt.feeds.GenericCSVData):
    params = (
        ('timeframe', bt.TimeFrame.Days),
        ('compression', 1),
        ('dtformat', '%Y-%m-%dT%H:%M:%SZ'),
        ('fromdate', datetime(2004, 1, 1, 0, 0, 0)),
        ('datetime', 0),
        ('open', 1),
        ('high', 2),
        ('low', 3),
        ('close', 4),
        ('volume', 5),
        ('openinterest', -1)
    )


if __name__ == '__main__':
    cerebro = bt.Cerebro(optreturn=False, stdstats=False)  # 최적화를 위한 옵션 설정
    cerebro.broker.setcommission(commission=0.2 / 100, leverage=100)  # 0.2% 수수료 설정
    cerebro.broker.setcash(10_000_000)
    cerebro.broker.set_coc(True)  # 종가 진입 설정

    options = {
        "QQQ": {},
    }

    for v in options.keys():
        collect_tick(v, "1d")

    # TimeFrame
    timeframe = "1d"

    for kind in options:
        for ts in [timeframe]:
            tick_path = f"./data/{kind}_{ts}_tick.csv"
            cryptoDataFeed = locals()[f"SymbolData{ts}"](dataname=tick_path)
            data_name = tick_path.split("/")[-1].split(".")[0]
            cerebro.adddata(cryptoDataFeed, name=data_name)

    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())

    cerebro.addstrategy(BollingerBandFixedTradeCount, log=True)  # 전략 추가
    cerebro.addanalyzer(bt.analyzers.PyFolio, _name='pyfolio')  # 결과 분석 추가

    results = cerebro.run()
    pyfoliozer = results[0].analyzers.getbyname('pyfolio')

    returns, positions, transactions, gross_lev = pyfoliozer.get_pf_items()
    returns.index = returns.index.tz_convert(None)

    print(f'\nFinal Portfolio Value {cerebro.broker.getvalue()}')
    qs.plots.snapshot(returns)

    print("\nGenerating report...")
    if not os.path.exists("./results"):
        os.makedirs("./results")
    qs.reports.html(returns, output=f'./results/BollingerBandFixedTradeCount_{int(time.time())}.html',
                    download_filename=f'./results/BollingerBandFixedTradeCount_{int(time.time())}.html',
                    title="BollingerBandFixedTradeCount")
    print("Complete")